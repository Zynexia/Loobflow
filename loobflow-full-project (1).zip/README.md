# Loobflow trifft Shopify

Setup-Anleitung und Beschreibung der API-Integration.